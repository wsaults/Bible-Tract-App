//
//  RootViewController.h
//  BibleTractApp
//
//  Created by William Saults on 10/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
    NSMutableArray* tracts;

}

@property (nonatomic, retain) NSMutableArray* tracts;


@end
