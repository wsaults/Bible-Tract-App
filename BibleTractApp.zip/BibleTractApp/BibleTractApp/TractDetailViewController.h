//
//  TractDetailViewController.h
//  BibleTractApp
//
//  Created by William Saults on 10/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TractDetailViewController : UIViewController {
    IBOutlet UIWebView *webView;
    NSString *selectedTract;
    
}

@property (nonatomic, retain) UIWebView *webView;
@property (nonatomic, retain) NSString *selectedTract;

@end
