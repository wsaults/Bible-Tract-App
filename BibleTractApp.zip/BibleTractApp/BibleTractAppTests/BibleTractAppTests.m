//
//  BibleTractAppTests.m
//  BibleTractAppTests
//
//  Created by William Saults on 10/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BibleTractAppTests.h"


@implementation BibleTractAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in BibleTractAppTests");
}

@end
