//
//  BibleTractAppTests.h
//  BibleTractAppTests
//
//  Created by William Saults on 10/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface BibleTractAppTests : SenTestCase {
@private
    
}

@end
